---
title: FFmpeg简明教程
tags:
  - 标签
categories:
  - 不好分类
date: 2021-11-08 21:06:15
---

### 图片处理命令

调整宽高

如将200*200裁剪到178*178

```
ffmpeg -i 42.png -s 178x178 178.png
ffmpeg -i input.png -vf scale=960:540 output.jpg //如果540写成-1，即scale=960:-1, 将会保持原始的宽高比。
```



### 在CentOS下编译FFmpeg

Get the Dependencies

```
yum install autoconf automake cmake freetype-devel gcc gcc-c++ git libtool make mercurial nasm pkgconfig zlib-devel bzip2  # mercurial 就是hg
mkdir ~/ffmpeg_sources
```

NASM

An assembler 汇编程序 used by some libraries. Highly recommended or your resulting build may be very slow.

```
cd ~/ffmpeg_sources
curl -O -L https://www.nasm.us/pub/nasm/releasebuilds/2.14.02/nasm-2.14.02.tar.bz2
./autogen.sh
./configure --prefix="$HOME/ffmpeg_build" --bindir="$HOME/bin"
make && make install
```

Yasm

Yasm is an assembler used by x264 and FFmpeg.

```
cd ~/ffmpeg_sources
git clone --depth 1 git://github.com/yasm/yasm.git
或curl -O -L https://www.tortall.net/projects/yasm/releases/yasm-1.3.0.tar.gz
autoreconf -fiv
./configure --prefix="$HOME/ffmpeg_build" --bindir="$HOME/bin"
make && make install
make distclean
```

libx264

H.264 video encoder.

Requires ffmpeg to be configured with --enable-gpl --enable-libx264.

```
cd ~/ffmpeg_sources
git clone --branch stable --depth 1 https://code.videolan.org/videolan/x264.git
PKG_CONFIG_PATH="$HOME/ffmpeg_build/lib/pkgconfig"./configure --prefix="$HOME/ffmpeg_build" --bindir="$HOME/bin" --enable-static
make && make install
make distclean
```

libx265

H.265/HEVC video encoder.

Requires ffmpeg to be configured with --enable-gpl --enable-libx265.

```
cd ~/ffmpeg_sources
hg clone https://bitbucket.org/multicoreware/x265
cd ~/ffmpeg_sources/x265/build/linux
cmake -G "Unix Makefiles" -DCMAKE_INSTALL_PREFIX="$HOME/ffmpeg_build" -DENABLE_SHARED:bool=off ../../source
make
make install
```

libfdk_aac

AAC audio encoder.

Requires ffmpeg to be configured with --enable-libfdk-aac (and --enable-nonfree if you also included --enable-gpl).

```
cd ~/ffmpeg_sources
git clone --depth 1 git://git.code.sf.net/p/opencore-amr/fdk-aac
autoreconf -fiv
./configure --prefix="$HOME/ffmpeg_build" --disable-shared
make && make install 
make distclean
```

libmp3lame

MP3 audio encoder.

Requires ffmpeg to be configured with --enable-libmp3lame.

```
cd ~/ffmpeg_sources
curl -L -O http://downloads.sourceforge.net/project/lame/lame/3.99/lame-3.99.5.tar.gz
./configure --prefix="$HOME/ffmpeg_build" --bindir="$HOME/bin" --disable-shared --enable-nasm
make && make install
make distclean
```

libopus

Opus audio decoder and encoder.

Requires ffmpeg to be configured with --enable-libopus.

```
cd ~/ffmpeg_sources
git clone git://git.opus-codec.org/opus.git
autoreconf -fiv
./configure --prefix="$HOME/ffmpeg_build" --disable-shared
make && make install
make distclean
```

libogg

Ogg bitstream library. Required by libtheora and libvorbis.

```
cd ~/ffmpeg_sources
curl -O http://downloads.xiph.org/releases/ogg/libogg-1.3.2.tar.gz
./configure --prefix="$HOME/ffmpeg_build" --disable-shared
make && make install
make distclean
```

libvorbis

Vorbis audio encoder. Requires libogg.

Requires ffmpeg to be configured with --enable-libvorbis.

```
cd ~/ffmpeg_sources
curl -O http://downloads.xiph.org/releases/vorbis/libvorbis-1.3.4.tar.gz
LDFLAGS="-L$HOME/ffmeg_build/lib" CPPFLAGS="-I$HOME/ffmpeg_build/include" ./configure --prefix="$HOME/ffmpeg_build" --with-ogg="$HOME/ffmpeg_build" --disable-shared
make && make install
make distclean
```

libvpx

VP8/VP9 video encoder and decoder.

Requires ffmpeg to be configured with --enable-libvpx.

```
cd ~/ffmpeg_sources
git clone --depth 1 https://chromium.googlesource.com/webm/libvpx.git
地址要改为  git clone https://github.com/webmproject/libvpx
./configure --prefix="$HOME/ffmpeg_build" --disable-examples --disable-unit-tests --enable-vp9-highbitdepth --as=yasm
make && make install
```

FFmpeg

```
cd ~/ffmpeg_sources
git clone --depth 1 git://source.ffmpeg.org/ffmpeg
PKG_CONFIG_PATH="$HOME/ffmpeg_build/lib/pkgconfig" ./configure --prefix="$HOME/ffmpeg_build" --extra-cflags="-I$HOME/ffmpeg_build/include" --extra-ldflags="-L$HOME/ffmpeg_build/lib" --bindir="$HOME/bin" --pkg-config-flags="--static" --enable-gpl --enable-nonfree --enable-libfdk-aac --enable-libfreetype --enable-libmp3lame --enable-libopus --enable-libvorbis --enable-libvpx --enable-libx264 --enable-libx265
make && make install 
make distclean
hash -r  //最新的是hash -d ffmpeg是什么意思？
```

更新

Keep the ffmpeg_sources directory and all contents if you intend to update as shown below. Otherwise you can delete this directory.

Updating Development of FFmpeg is active and an occasional update can give you new features and bug fixes. First, remove the old files and then update the dependencies:

```
rm -rf ~/ffmpeg_build ~/bin/{ffmpeg,ffprobe,ffserver,lame,vsyasm,x264,x265,yasm,ytasm}
```

1. yum install autoconf automake cmake gcc gcc-c++ git libtool make mercurial nasm pkgconfig zlib-devel

Update Yasm

```
cd ~/ffmpeg_sources/yasm
make distclean
git pull
```

Then run ./configure, make, and make install as shown in the Install yasm section.

Update x264

```
cd ~/ffmpeg_sources/x264
make distclean
git pull
```

Then run ./configure, make, and make install as shown in the Install x264 section.

Update x265

```
cd ~/ffmpeg_sources/x265
rm -rf ~/ffmpeg_sources/x265/build/linux/*
hg update
cd ~/ffmpeg_sources/x265/build/linux
```

Then run cmake, make, and make install as shown in the Install x265 section.

Update libfdk_aac

```
cd ~/ffmpeg_sources/fdk_aac
make distclean
git pull
```

Then run ./configure, make, and make install as shown in the Install libfdk_aac section.

Update libvpx

```
cd ~/ffmpeg_sources/libvpx
make clean
git pull
```

Then run ./configure, make, and make install as shown in the Install libvpx section.

Update FFmpeg

```
cd ~/ffmpeg_sources/ffmpeg
make distclean
git pull
```

Then run ./configure, make, and make install as shown in the Install FFmpeg section.

Reverting changes made by this guide

```
rm -rf ~/ffmpeg_build ~/ffmpeg_sources ~/bin/{ffmpeg,ffprobe,ffserver,lame,vsyasm,x264,yasm,ytasm}
# yum erase  xxx
hash -r
```

参考

https://trac.ffmpeg.org/wiki/CompilationGuide/Centos

### X264 编码指南

通常有2种码率控制模式：Constant Rate Factor (CRF) or Two-Pass ABR



#### CRF恒定码率系数

目的是为了输出质量，而不关心大小；

码率不可控，不推荐用于网络流

选择一个CRF值：

范围为 0-51，0 为无损，默认23，建议值17，18

CRF值每加6，码率大概减少一半；每次减6则会使码率增加一倍。

选择一个预设preset：

预设是一系列选项的集合，能够在编码速度和压缩率之间做出一个权衡，

速度稍慢的预设，相同质量时，占用空间更小。从而码率也更低

通过x264 --fullhelp 可以看到各个preset的具体设置

你也可以根据输入文件的特性选择-tune选项，

如果你的输入文件是动画，则可以用animation。

另一个可选的参数是-profile:v，通常不用，除非目标设备仅支持某种profile.

```
ffmpeg -i input -c:v libx264 -preset slow -crf 22 -c:a copy output.mkv
ffmpeg -i input -c:v libx264 -preset slow -crf 18 -c:a copy -pix_fmt yuv420p output.mkv  # 质量与输入差不多，但可能大小更小一些
```

使用静态图像创建视频：

```
ffmpeg -loop 1 -framerate 2 -i input.png -i audio.m4a -c:v libx264 -preset medium -tune stillimage -crf 18 -c:a copy -shortest -pix_fmt yuv420p output.mkv
```

#### Two-Pass

确定大小的文件，视频质量并不重要。

例如：你的视频时长 10 minutes 想要输出一个 50 MB大小的文件.(比特率= 文件大小/ 时长)

```
(50 MB * 1024*8 [converts MB to kbit]) / 600 seconds = ~683 kilobits/s （总码率）
683k - 128k (期望的音频码率) = 555k （视频比特率）
```

从而：

```
ffmpeg -y -i input -c:v libx264 -b:v 555k -pass 1 -an -f mp4 /dev/null 
ffmpeg -i input -c:v libx264  -b:v 555k -pass 2 -c:a libfdk_aac -b:a 128k output.mp4
```

#### 无损H.264编码

通过 -crf 0实现，可同时配合2个有用的预设ultrafast 或 veryslow。

快速编码

```
ffmpeg -i input -c:v libx264 -preset ultrafast -crf 0 output.mkv
```

高压缩比

```
ffmpeg -i input -c:v libx264 -preset veryslow -crf 0 output.mkv
```

#### 覆盖默认preset值

通过x264-params，或libx264 私有选项，（参见ffmpeg -h encoder=libx264）。一般不建议使用。

```
ffmpeg -i input -c:v libx264 -preset slow -crf 22 -x264-params keyint=123:min-keyint=20 -c:a copy output.mkv
```

#### ABR (Average Bit Rate)

```
ffmpeg -i input -c:v libx264 -b:v 1000k output.mp4
```

对简单的画面，用小于设定的码率去编码，而对于复杂的画面，将进行高质量的编码，从而在整体上达到指定的码率，和2-pass一起用效果更好，同时也可以指定max bit rate防止码率产生大的波动。

#### CBR (Constant Bit Rate)

没有原生的CBR模式，但可模拟。

```
ffmpeg -i input -c:v libx264 -x264-params "nal-hrd=cbr"  -b:v 1M -minrate 1M -maxrate 1M -bufsize 2M out.m2v
```

-bufsize是一个“码率控制buffer”, 会在每2M数据内达到你要求的均值

```
ffmpeg -i input -c:v libx264 -crf 20-maxrate 1M -bufsize 2M output.mp4
```

这会有效地接近crf 20，但当输出超过1MBit/s时，会增加crf的值。 To reach a perfect maximum bit rate, use two-pass

```
ffmpeg -i input -c:v libx264 -b:v 1M -maxrate 1M -bufsize 2M -pass 1 -f mp4 /dev/null
ffmpeg -i input -c:v libx264 -b:v 1M -maxrate 1M -bufsize 2M -pass 2 output.mp4
```

#### 视频兼容性

可以指定-profile:v baseline -level 3.0

#### 网络视频

对于mp4,m4v,mov,不适用于mkv,可以在输出选项中加上-movflags +faststart，可以在全部下载完成之前就可以开始播放。(会将moov atom 放在文件开头)

```
ffmpeg -i input.mp4 -c copy -movflags +faststart output.mp4 #不会编码
```

If your input files are RGB, Use -c:v libx264rgb instead. 某些音乐文件包含专辑封面，一般是音频文件里面有个视频流，如果没有专辑封面，可以自已创建一个，用上面一样的命令：

```
ffmpeg -loop 1 -framerate 2 -i input.png -i audio.m4a -c:v libx264 -preset medium -tune stillimage -crf 18 -c:a copy -shortest -pix_fmt yuv420p output.mkv
```

给音乐加上特效

```
ffmpeg -i input.mp3 -filter_complex \
"[0:a]avectorscope=s=640x518[left]; \
[0:a]showspectrum=mode=separate:color=intensity:scale=cbrt:s=640x518[right]; \
[0:a]showwaves=s=1280x202:mode=line[bottom]; \
[left][right]hstack[top]; \
[top][bottom]vstack,drawtext=fontfile=Vera.ttf:fontcolor=white:x=10:y=10:text='\"Song Title\" by Artist'[out]" \
-map "[out]" -map 0:a -c:v libx264 -preset fast -crf 18 -c:a copy output.mkv
```

带宽有限制时，应该使用VBV (Video Buffer Verifier) with the -maxrate and -bufsize options

假设上传速率为1024kbit / s，可以利用80％= 820 kbit / s。音频会消耗128kbit/s，最后晟大约692 kbit / s的视频：这就是你-maxrate值。

If you use -maxrate 960k then use a -bufsize of 960k-1920k.（会有1到2秒的延迟）

参考

https://trac.ffmpeg.org/wiki/Encode/H.264

### X265 编码

比x264节省约25-50％的码率

选择ultrafast，编码过程将快速运行，但与medium相比，文件大小会更大。视觉质量将是相同的。

```
ffmpeg -y -i input -c:v libx265 -b:v 2600k -x265-params pass=1 -an -f mp4 /dev/null 
ffmpeg -i input -c:v libx265 -b:v 2600k -x265-params pass=2 -c:a aac -b:a 128k output.mp4
```

参考

https://trac.ffmpeg.org/wiki/Encode/H.265

### 视频裁剪

#### 快速定位

将ss放在-i的前面

```
ffmpeg -ss 00:23:00 -i input  -frames:v 1 out1.jpg
```

基于关键帧的搜索会非常快，现在新版也非常精确了！noaccurate_seek 选项可以用于查找前面最近的关键帧

#### 精确定位

将ss放在-i的后面

```
ffmpeg -i input.mkv -ss 00:23:00 -frames:v 1 out2.jpg
```

输入文件会一帧一帧地进行解码直到到达ss所指定的位置，因此会非常慢。指定时间越长，需要等待的时间也会越长。

#### 快速并且精确定位

在输入文件前后同时指定ss参数

```
ffmpeg -ss 00:22:30 -i input.mkv -ss 00:00:30 -frames:v 1 out3.jpg
```

综合了上面2种方法的优点。

首先快速定位到3分钟之前的某个时间点，然后从该时间点开始一帧一帧地慢慢解码到3分钟。

首先快速定位到00:02:30附近的关键帧处，然后开始慢慢往后搜索30秒。速度更快。

注意上面2个ss时间点(00:02:30和00:00:30)的设置依赖于关键帧的间隔（即GOP的大小）

#### 切割片断

将ss和t参数联合使用，其中t参数指定时长，例如“-ss 60 -t 10”将切割一段从60秒到70秒的片断；

或者使用to选项指定结束时间点，如“ -ss 60 -to 70”也一样切割一段从60秒到70秒的片断；t和to不能同时使用，如果同时指定，默认用t。

#### 注意

如果仅仅在-i之前指定了ss选项，那么时间戳会被重置为0，此时选项t和选项to产生的效果不一样。要保留原始时间戳，可以用-copyts选项(-c copy -copyts)

```
ffmpeg -ss 00:01:00 -i video.mp4 -to 00:02:00 -c copy cut.mp4 #得到从00:01:00 到 00:03:00的片断，不是想要的结果！
ffmpeg -i video.mp4 -ss 00:01:00 -to 00:02:00 -c copy cut.mp4  # 真正得到从00:01:00 到 00:02:00的片断。
ffmpeg -ss 00:01:00 -i video.mp4 -to 00:02:00 -c copy -copyts cut.mp4  //也是想要的结果，得到从00:01:00 到 00:02:00的片断，而且速度快
```

如果你切割的时候使用了流拷贝stream copy (-c copy)，并且想用 concat demuxer来合并你切割出来的片断，你需要指定`-avoid_negative_ts 1`:

```
ffmpeg -ss 00:03:00 -i video.mp4 -t 60 -c copy -avoid_negative_ts 1 cut.mp4
```

如果需要编码，比如得到120s开始的一分钟，则需要用-ss 120 -i some.mov -to 60，而不是-to 180

#### 时间格式

[HH:MM:SS]格式或以秒为单位，如00:02:30 或者 150。如果使用了小数，如02:30.05，小数点后面的05表示1秒*5%，即50毫秒 ，如02:30.5表示2分钟，30秒，500毫秒(即半秒)。

参考

http://trac.ffmpeg.org/wiki/Seeking

### 字幕处理

mkv等格式文件以流的形式存储字幕，而mp4不支持这种方式。如果希望生成带字幕的mp4文件，只能将字幕“烧录”到视频中。

2个滤镜: subtitles和ass

编译时需要指定：

```
--enable-libass # ASS (Advanced SSA), SSA (SubStation Alpha) subtitle
```

从容器中提取字幕流，生成字幕文件

```
ffmpeg -i input.mkv output.srt
ffmpeg -i in.avi -vf subtitles=subtitle.srt out.avi 

ffmpeg -i in.avi -vf "ass=subtitle.ass" out.avi  #注意需要先转换为ass:
ffmpeg -i subtitle.srt subtitle.ass
```

list all the subtitle codecs that FFmpeg supports:

```
ffmpeg -codecs | grep "^...S"
ffmpeg -i video.mkv -vf subtitles=video.mkv out.avi# 如果字幕在video.mkv中，将输入文件的第一个字幕流合成到视频流中,最好用上面的那种先导出字幕，然后合成。
```

将某容器第二个字幕流合成到另一个容器的视频流中输出：

```
ffmpeg -i input.mkv -vf subtitles=video.mkv:si=1 output.mkv  # index?
```

基于图片的字幕

dvdsub is a type of picture-based overlay subtitles

```
ffmpeg -i input.mkv -filter_complex [0:v][0:s]overlay[v" -map [v] -map 0:a <output options> output.mkv
```

参考

http://trac.ffmpeg.org/wiki/HowToBurnSubtitlesIntoVideo

### Metadata

```
ffmpeg -i cuc_ieschool.flv -metadata title="elesos title" -metadata year="2020" out.flv //有些需要容器格式支持才能写进去，此外还有copyright，author等
```

可以在打开码流前指定各种参数，比如：探测时间、超时时间、最大延时、支持的协议白名单等

```
-map_metadata -1 表示清除所有元数据
AVDictionary *options = NULL;
av_dict_set(&options, “probesize”, “4096", 0);
av_dict_set(&options, “max_delay”, “5000000”, 0);

AVFormatContext *ic = avformat_alloc_context();
if (avformat_open_input(&ic, url, NULL, &options) < 0) {
    loge("could not open source %s", url);
    return -1;
}
```

av_dict_set支持配置哪些key呢？搜索一下probesize关键字，可以发现

```
libavformat\options_table.h
```

AVCodec相关的 options 选项在

```
libavcodec/options_table.h 
```

如何通过api设置metadata：

可以在avformat_write_header之前(不是调用时)设置 AVFormatContext>metadata

```
if(av_dict_set(&ofmt_ctx->metadata,"title","elesos.com", 0) < 0){
		av_log(NULL, AV_LOG_ERROR, "av_dict_set failed.\n");
	}
...
ret = avformat_write_header(ofmt_ctx, NULL);
```

参考

https://wiki.multimedia.cx/index.php/FFmpeg_Metadata

https://blog.51cto.com/ticktick/1891948

### 树莓派 硬编 264

编译出来后，验证编译出来的库是否支持（这个只能查编译出来的）：

```
ffmpeg -decoders | grep mmal
V..... h264_mmal h264 (mmal) (codec h264) 
V..... mpeg2_mmal mpeg2 (mmal) (codec mpeg2video) 
V..... mpeg4_mmal mpeg4 (mmal) (codec mpeg4) 
V..... vc1_mmal vc1 (mmal) (codec vc1)


ffmpeg -encoders | grep omx  //或用-codecs 
V..... h264_omx             OpenMAX IL H.264 video encoder (codec h264)
```

也可以通过编译ffmpeg的config.h中查看。比如

```
#define CONFIG_H264_VAAPI_ENCODER 1
```

如果想要查询所有编码器：要用configure

```
./configure --list-encoders   | grep omx
ffmpeg -i input -c:a copy -c:v h264_omx output
```

参考

http://www.redhenlab.org/home/the-cognitive-core-research-topics-in-red-hen/the-barnyard/hardware-encoding-with-the-raspberry-pi

https://www.jianshu.com/p/61e2c3cbc412