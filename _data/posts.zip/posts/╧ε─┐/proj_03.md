---
title: 知识图谱 分类标注
date: 2021-03-10 15:47:14
tags:
- 项目
categories:
- 项目
---
知识图谱分类标记是推荐系统的前期工作。


### 工具
Docker, Laravel, [Vue.js](https://cn.vuejs.org/v2/guide/), [Element](https://element.eleme.cn/#/zh-CN/component/installation)
![](/images/knowledge-graph-tool.png)

主动将原Flash版标注工具重构为网页版，减少安装成本，便于版本更新。

自学laravel+vue后完成。