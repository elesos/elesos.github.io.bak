---
title: Abseil
tags:
  - 标签
categories:
  - 不好分类
date: 2021-07-03 15:21:59
---

一个开源的C++库，从谷歌的代码库里面收集而来，可以扩展C++标准库的功能

通过Bazel来编译，也可以使用cmake

https://github.com/abseil/abseil-cpp
