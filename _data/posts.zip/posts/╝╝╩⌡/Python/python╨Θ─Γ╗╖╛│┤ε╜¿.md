---
title: python虚拟环境搭建
tags:
  - 标签
categories:
  - 不好分类
date: 2021-07-28 11:08:23
---

https://www.liaoxuefeng.com/wiki/1016959663602400/1019273143120480



2.7安装在C:\Python27

3.8在C:\Users\ws\AppData\Local\Programs\Python\Python38





1,将python改名python2

将pip和pip2.7删除，只保留pip2

将python加到path变量中：C:\Python27和C:\Python27\Scripts



2,将python改名python3

将pip和pip3.8删除，只保留pip3

一样加环境变量



以后就通过python2和python3运行。

