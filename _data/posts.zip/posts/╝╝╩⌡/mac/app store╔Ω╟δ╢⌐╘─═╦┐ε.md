---
title: app store申请订阅退款
tags:
  - mac
categories:
  - mac
date: 2021-07-08 08:00:20   
---

https://reportaproblem.apple.com/

请问您需要什么帮助？

选择：请求退款，

选择：儿童/未成年人未经允许进行了购买

然后提交。
