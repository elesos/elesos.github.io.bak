---
title: C++经典书籍推荐
tags:
  - C/C++
categories:
  - C/C++
date: 2021-07-02 21:14:22
---

https://stackoverflow.com/questions/388242/the-definitive-c-book-guide-and-list

definitive：最权威的
