---
title: WebRTC 开源服务器
tags:
  - webrtc
categories:
  - webrtc
date: 2021-07-04 12:03:47
---

## Jitsi

SFU， 开发语言（java, lua）

## Kurento

开发语言（java）

## mediasoup

## Janus

开发语言（C语言）

## Licode

## 参考

http://www.ctiforum.com/news/guonei/572996.html
