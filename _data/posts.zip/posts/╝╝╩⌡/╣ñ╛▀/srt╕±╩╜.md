---
title: srt格式
tags:
  - srt
categories:
  - 不好分类
date: 2021-07-21 10:20:39
---

四部分构成：

- 字幕序号
- 字幕显示的起始时间
- 字幕内容（可多行）
- 空白行（表示本字幕段的结束）



```
15
00:00:23,790 --> 00:00:24,620
Okay.

16
00:00:25,420 --> 00:00:27,660
Here we are on Madeline Beyer.

```

`hour:minute:second.millisecond --> hour:minute:second.millisecond`

 或
`hour:minute:second,millisecond --> hour:minute:second,millisecond`





https://www.cnblogs.com/tocy/p/subtitle-format-srt.html