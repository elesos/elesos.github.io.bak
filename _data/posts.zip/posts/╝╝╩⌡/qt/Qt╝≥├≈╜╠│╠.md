---
title: Qt简明教程
tags:
  - Qt
categories:
  - Qt
date: 2021-07-02 22:17:26
---



| 时间           | 版本                                                         |
| -------------- | ------------------------------------------------------------ |
| 2005年6月27日  | Qt 4.0                                                       |
| 2008年5月      | Qt 4.4                                                       |
| 2012年12月19日 | Qt 5.0                                                       |
| 2017年5月31日  | Qt 5.9                                                       |
| 2021.5.25      | 5.12 LTS                                                     |
| 2020年5月26日  | Qt 5.15 lts only for Commercial licenses                     |
| 2020.12.8      | Qt6                                                          |
| 2021.5.6       | 6.1                                                          |
| 2021年7月1日   | Qt 6.1.2                                                     |
| 2021.9.30      | 6.2LTS  https://www.qt.io/blog/qt-6.2-lts-released  Qt 6.2 fully supports [macOS on Apple Silicon](https://www.qt.io/blog/qt-on-apple-silicon?hsLang=en). |
| 2021.10.27     | 6.2.1                                                        |

https://en.wikipedia.org/wiki/Qt_version_history

## 下载 

https://download.qt.io/archive/qt/5.9/5.9.9/ open source offline installers are not available any more since Qt 5.15 

Qt 5.15.2 can be installed by using the maintenance tool： https://download.qt.io/official_releases/online_installers/

https://download.qt.io/archive/qt/





关联

```
connect(sender, SIGNAL(signal()), receiver, SLOT(slot()));
```

- 一个信号可以连接多个槽
- 一个信号可以连接另外一个信号

```
connect(spinNum, SIGNAL(valueChanged(int)), this, SIGNAL (refreshInfo(int));
```

- 信号与槽的参数个数和类型需要一致

所谓信号槽，实际就是观察者模式。



多模块用pri

输出

qDebug() << QString::fromLocal8Bit("跟我学Qt6");



### 在UI界面上关联信号与槽

ui中选中比如一个 chkBoxUnder 组件，右键调出其快捷菜单。在快捷菜单中单击菜单项“Go to slot…”



头文件声明的函数名上面，右键，选择“Refactor重构”→“Add Definition in elesos.cpp”，就可以自动在cpp中生成定义。



在 UI 设计器里，单击上方工具栏里的“Edit Signals/Slots”按钮，窗体进入信号与槽函数编辑状态

将鼠标移动到按钮上方，再按下鼠标左键，移动到窗体的空白区域释放左键，这时出现信号与槽的关联设置对话框。左侧的列表框里信号，右边的列表框里显示了槽函数（如果没有显示，把复选框勾选上）。

http://c.biancheng.net/view/1822.html

https://www.cnblogs.com/schips/p/framework-cpp-qt-02-ui-layout-manage.html









## Qt源码解析

安装qt时选择安装源码





## 示例解析

基于6.2.1

Qt官方示例解析





Qt Quick for building modern, fluid, animated UIs

 5.https://doc.qt.io/qt-6/qtconcurrent-imagescaling-example.html
 QFuture class represents the result of an asynchronous computation.
 QPromise class provides a way to store computation results to be accessed by QFuture
 异步下载

=============================================

《Qt Creator快速入门》第3版示例解析





8.11-01\myscene



7，10-01\mydrawing

```
drawArc
```

角度需要用度数*16， 0度指向3时，角度为正时逆时针。

文字渐变

6.06-08\myeventfilter

为何要实现事件过滤器

this表示要在本部件 中监视textEdit和spinBox的事件，在eventFilter中截获并处理 2个子部件的事件。返回true表示已处理，不希望再被处理。

如果不用事件过滤器，就需要子类化2个部件，然后实现对应的事件处理函数才行。《Qt Creator快速入门》P129

```
  QKeyEvent myEvent(QEvent::KeyPress,Qt::Key_Up,Qt::NoModifier);
```

表示一个向上方向键被按下的事件



5.06-05\mykeyevent

4，06-04\mykeyevent

键盘事件

3.06-03\mymouseevent

```
//鼠标移动事件默认按下鼠标按键移动后才会 触发，
 //如果需要不按鼠标按键也可以触发移动事件就需要在构造函授添加
  //代码：setMouseTracking(true);
```

全屏处理









2，06-02\myevent

子类实现event和keyPressEvent，父类添加eventFilter处理函数，并在构造函数中给子类安装installEventFilter

event.png

顺序：先是eventFilter，然后是焦点部件的event,然后是焦点部件的事件处理函数，比如keyPressEvent。





事件：可以被QObject子类接收和处理，5种处理事件的方法：

1，重新实现paintEvent等事件处理函数

2，重新实现notify,   page116 《Qt Creator快速入门》

3，向QApplication安装事件过滤器

4，重新实现event函数

5，在对象上安装事件过滤器，比如widge含有一个lineEdit，则lineEdit->installEventFilter(this)表示在widget上为lineEdit安装事件过滤器。一般用于拦截。

常用1和5





1，06-01\myevent

```
 event->ignore(); 
```

如果忽略就会传递到父对象。

===========================================



###  





8，Tablet Example

QTabletEvent ：Qt will first send a tablet event, then if it is not accepted by any widget, it will send a mouse event. 





7，Touch Dials Example

触摸事件 https://doc.qt.io/qt-6/qtouchevent.html#details

6.Touch Knobs Example

触摸事件，需要根据widget和graphics items分别设置下属性setAttribute(Qt::WA_AcceptTouchEvents);或  setAcceptTouchEvents(true);

不是笔记本的触摸板



5.Scribble Example 画图应用

菜单的使用addAction，事件处理，获取鼠标位置 

初始化时将图片设置比窗口大，避免调整窗口大小时也调整图片的大小，update部分重绘

Finger Paint Example：跟这个示例功能差不多，但用的是touch screen触摸事件



4，Getting Started Programming with Qt Widgets 实现一个记事本

用到文本文件读写



3，Calculator Example

```
const char *member接收SLOT(pointClicked()
```

 which button sent the signal using [QObject::sender](https://doc.qt.io/qt-6/qobject.html#sender)().

 MC=clearMemory
 MR=readMemory
 MS=setMemory
 M+=addToMemory



2，Mouse Button Tester  鼠标事件



1，Analog Clock Example

 QPainter的使用

y坐标向下部分为0->200

先平移到（100，100），scale变大变小。

用3个点画了一个3角形，刚开始指向12点

12小时，一小时为30度，旋转的是坐标系统。所以每次点不变。



1.2  Analog Clock Window Example

设置了timer,调renderLater，最后到renderNow

关联类Raster Window Example ： QBackingStore用于管理window







#### Next

学习进度：

《Qt creator快速入门》

2.2.2，qt发布时需要复制libgcc_s_seh-1.dll,libstdc++-6.dll,libwinpthread-1.dll和qwindows.dll(放在platforms目录下)

2.2.3 设置应用程序图标

3  有QWidget类图

3.1.2 

![image-20211225105056011](image-20211225105056011.png)

p56









## qt资料

Qt 资料大全 https://blog.csdn.net/liang19890820/article/details/51752029

基本上看一去二三里的这个就够了https://blog.csdn.net/liang19890820/article/details/50277095

https://www.devbean.net/2012/08/qt-study-road-2-catelog/ 亮哥推荐

Qt 快速入门系列教程  - http://shouce.jb51.net/qt-beginning/  简洁明了，干净排版，目录清晰。 分基础，图形，数据，网络篇，进阶，过度篇。

Qt开发学习教程  - https://blog.51cto.com/u_9291927/2138876  - 来自天山老妖，51博客上的，分为基础，中阶，高阶，其他。





Q_OBJECT宏： 在类的私有部分声明这个宏





运行时类别信息（RTTI）：实例化对象所属的类信息在运行时才真正确定  dynamic_cast

```
label->setAttribute(Qt::WA_DeleteOnClose);
```



按钮在 Qt 中被称为`QPushButton`

`QDialog::exec()`实现应用程序级别的模态对话框(翻译为被执行，语气强烈，所以为模态)，`QDialog::show()`实现非模态对话框（翻译为守，比较被动式，为非模态）



参考 

https://qmlbook.github.io  focuses on Qt Quick, but also provides the information needed to use QML together with C++.



https://doc.qt.io/qt-6/qtexamplesandtutorials.html  含下面2个子页面示例列表：

https://doc.qt.io/qt-6/qtexamples.html（这个比较全）和 https://doc.qt.io/qt-6/all-examples.html

### 书籍推荐

入门推荐《C++ GUI Qt 4编程》https://blog.csdn.net/net_syc/article/details/80236963



https://hk1lib.org/?logoutAll=&signAll=1&ts=1512  书籍

# 栈和堆

A a；栈

堆上创建对象，使用`new`运算符



写数据前QMutexLocker locker(&QMutex);







blockSignals



qt 用 QEventLoop可以阻塞工作线程，同时不影响主线程

类似这样的将要删除的接口可以用  QT_DEPRECATED_X("XXXX")  定义一下，这样的接口被引用，会有警告信息



# Linguist

lupdate可以把.h、.cpp、.ui中需要翻译的字符串提取出来形成.ts文件，然后用linguist翻译。用lerealse生成.qm。

翻译一个含有tr()调用的Qt应用程序需要以下三步：
1. 运行ludate，从应用程序的源代码中提取所有用户可见的字符串。
2. 使用Qt Linguist翻译该应用程序。
3. 运行lrelease，生成二进制.qm文件，应用程序可以使用QTranslator加载这个文件。



vs插件目录要配置到

D:\Qt\Qt5.5.1\5.5\msvc2013

环境变量

- QTDIR：D:\Qt\Qt5.5.1\5.5\msvc2013
- PATH：%QTDIR%\bin

## 常用语法



常用颜色值

白色 (255, 255, 255).









#### tr

All classes that inherit [QObject](https://doc.qt.io/qt-5/qobject.html) have a `tr()` function. 

QObject::tr("Hello world!")







#### Q_DECLARE_METATYPE



#### Q_DECLARE_PRIVATE

用于声明对应的私有类，比如XXXPrivate 类

https://wiki.qt.io/D-Pointer

Binary compatibility ：更新库不需要重新编译

d-pointer：指向一个私有实现子类，d弟，Q_D返回私有子类指针。

q-pointer:指向父类。



QMetaObject::invokeMethod调用一个对象的方法



#### QStringList 

字符串列表,从QList <QString>继承而来, 合并字符串使用join( ),类似php的implode,拆分字符串split

qFuzzyCompare： If one of the values is likely to be 0.0, one solution is to add 1.0 to both values.



#### Qt界面focus

setFocus

QStyledItemDelegate 都是来控制显示，自定义显示效果的

#### The Box Model

https://doc.qt.io/qt-5/stylesheet-customizing.html#the-box-model



QFrame是基本控件的基类，QWidget是QFrame基类。



x()：左上角的坐标，geometry.x()：不包括标题栏、边框的客户区，frameGeometry.x()：左上角的坐标

width()：客户区的宽度，geometry.width()：客户区的宽度

frameGeometry.width()：窗口真正的宽度（包括边框和标题栏）



QApplication::desktop()->availableGeometry 可以获取可操作区域

https://doc.qt.io/qt-5/stylesheet-reference.html







# 用法

#### 改变QLabel背景颜色

label->setStyleSheet("QLabel{background-color:rgb(200,101,102);}");  //设置样式表

#### Qt之QSS使用

https://blog.csdn.net/u010780613/article/details/50510581

简单来说，每个qss语句由`选择器`和一条或者多`申明`构成，每条`申明`都是`键值对`的形式，`键`是`选择器`的`属性`，`值`是对这个属性的`设置`。选择器放在`{}`外面，生命在`{}`里面，不同是声明设置之间用`;`隔开。声明的键和值之间用`:`分隔。

```text
selector {declaration1; declaration2; ... declarationN }
```

可以多个选择器对应一个申明语句 选择器之间用逗号隔开。

```text
QPushButton,QLabel,QLineEdit {color:#222; background-color:#fff;}
```









# 一天一个类





#### QComboBox 

by default a [QStandardItemModel](https://doc.qt.io/qt-5/qstandarditemmodel.html) stores the items and a [QListView](https://doc.qt.io/qt-5/qlistview.html) subclass displays the popuplist. 

将这个QListWidget设置为QComboBox的View，而将QListWidget的Model设置为QComboBox的Model



QStackedWidget 显示一个界面，常与tab搭配使用

QButtonGroup将相同功能的按键，设为一个分组，然后可以进行 单选 或 多选

QToolButton用在QToolBar里面，只显示图标，QToolButton的一种经典用法是选择工具。例如，绘图程序中的“笔”工具。就是工具栏上面那些按钮。

#### QListView和QListWidget的区别

QListView是基于Model，而QListWidget是基于Item，往QListView中添加条目需借助QAbstractListModel，而在QListWidget中添加条目可以直接additem

QListWidget继承于QListView





#### QGraphicsItem

实现自己的，要实现2个方法

QGraphicsScene ，used together with [QGraphicsView]

1，创建继承自**QGraphicsView**的窗口

2，创建继承自**QGraphicsScene**的画布

3、将画布设置给View窗口QGraphicsView::setScene(self.scene)

4，在画布Scene上添加元素：自定义item，继承自**QGraphicsItem**该类，并通过QGraphicsScene::addItem(item)的方法将item添加到画布

#### Qt Widgets、QML、Qt Quick 的区别

> QML is a user interface specification and programming language.

QML 是一种用户界面规范和标记语言，文件格式以 .qml 结尾。

> Qt Quick is the standard library of types and functionality for QML.

Qt Quick 是 QML 类型和功能的标准库

widgets 主要针对桌面的，qml 主要针对移动端的！



常见问题



2.Project ERROR: Unknown module(s) in QT: winextras

https://github.com/qt/qtwinextras



1，class QWheelEvent' has no member named 'delta'

https://stackoverflow.com/questions/66268136/how-to-replace-the-deprecated-function-qwheeleventdelta-in-the-zoom-in-z

use  event->angleDelta().y()

